﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Aplicacion.DTO
{
    public record UpdateActArtDTO(
        int id,
        string nombre,
        string descripcion,
        string? codigo,
        string? unidad_medida,
        int? id_Rubro
    );
}