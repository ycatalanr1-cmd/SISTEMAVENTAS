﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Aplicacion.DTO
{
    public record CreateArticuloDTO(
        string Nombre,
        string Descripcion,
        string? codigo,
        string? unidad_medida,
        int? id_Rubro
    );
}