﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Aplicacion.DTO
{
    public record ArticuloDTO(
        int id,
        string nombre,
        string descripcion,
        string? codigo,
        string? unidad_medida,
        string? Categoria
    );
}