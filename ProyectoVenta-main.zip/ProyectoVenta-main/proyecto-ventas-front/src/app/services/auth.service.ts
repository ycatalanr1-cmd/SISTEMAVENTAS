import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';
import { environment } from '../../environments/environment';
import { LoginRequest, AuthResponse, Rol } from '../models/auth.model';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly url = `${environment.apiUrl}/AuthControlador`;

  constructor(private http: HttpClient) { }

  login(data: LoginRequest): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(`${this.url}/login`, data).pipe(
      tap(res => {
        localStorage.setItem('token', res.token);

        let idProveedor: number | null = null;
        try {
          const payload = JSON.parse(atob(res.token.split('.')[1]));
          const idProv = payload['IdProveedor'] || payload['idProveedor'];
          idProveedor = idProv ? parseInt(idProv, 10) : null;
        } catch (error) {
          console.error('Error al decodificar el token:', error);
        }

        localStorage.setItem('usuario', JSON.stringify({
          nombre: res.nombre,
          email: res.email,
          rol: res.rol,
          idRol: res.idRol,
          id_Proveedor: idProveedor
        }));
      })
    );
  }

  logout(): void {
    localStorage.removeItem('token');
    localStorage.removeItem('usuario');
  }

  getToken(): string | null {
    return localStorage.getItem('token');
  }

  isLoggedIn(): boolean {
    return !!this.getToken();
  }

  getUsuario(): { nombre: string; email: string; rol: string; idRol: number; id_Proveedor: number | null } | null {
    const raw = localStorage.getItem('usuario');
    return raw ? JSON.parse(raw) : null;
  }

  getRol(): Rol | null {
    const usuario = this.getUsuario();
    if (!usuario) return null;

    switch (usuario.idRol) {
      case 1: return 'Administrador';
      case 2: return 'GestorCompras';
      case 3: return 'AdministradorProveedor';
      case 4: return 'Auditor';
      case 5: return 'CreadorPedidos';
      default: return null;
    }
  }

  getNombreRolBonito(): string {
    switch (this.getRol()) {
      case 'Administrador': return 'Administrador del Sistema';
      case 'GestorCompras': return 'Gestor de Compras';
      case 'AdministradorProveedor': return 'Administrador de Proveedor';
      case 'Auditor': return 'Auditor / Reportes';
      case 'CreadorPedidos': return 'Creador de Pedidos';
      default: return '';
    }
  }

  // ====== VERIFICADORES DE ROL ======
  esAdmin(): boolean { return this.getRol() === 'Administrador'; }
  esGestorCompras(): boolean { return this.getRol() === 'GestorCompras'; }
  esAdminProveedor(): boolean { return this.getRol() === 'AdministradorProveedor'; }
  esAuditor(): boolean { return this.getRol() === 'Auditor'; }
  esCreadorPedidos(): boolean { return this.getRol() === 'CreadorPedidos'; }
  esEmpleado(): boolean { return this.esGestorCompras(); }
  esProveedor(): boolean { return this.esAdminProveedor(); }

  // ====== RUTAS ======
  getRutaInicio(): string {
    switch (this.getRol()) {
      case 'Administrador': return '/admin/dashboard';
      case 'GestorCompras': return '/empleado/pedidos';
      case 'AdministradorProveedor': return '/proveedor/ofertas';
      case 'Auditor': return '/auditor/reportes';
      case 'CreadorPedidos': return '/creador/pedidos';
      default: return '/login';
    }
  }

  getIdDepartamento(): number | null {
    const token = this.getToken();
    if (!token) return null;

    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      const idDepto = payload['IdDepartamento'] || payload['idDepartamento'];
      return idDepto ? parseInt(idDepto, 10) : null;
    } catch (error) {
      console.error('Error al decodificar el token:', error);
      return null;
    }
  }

  getRutaHubReportes(): string {
    switch (this.getRol()) {
      case 'Auditor': return '/auditor/reportes';
      case 'GestorCompras': return '/empleado/pedidos';
      case 'Administrador':
      default: return '/admin/reportes';
    }
  }

  // ====== PERMISOS ESPECÍFICOS ======
  puedeGestionarArticulos(): boolean { return this.esAdmin(); }
  puedeGestionarUsuarios(): boolean { return this.esAdmin(); }
  puedeGestionarProveedores(): boolean { return this.esAdmin(); }
  puedeCrearPedidos(): boolean { return this.esAdmin() || this.esGestorCompras(); }
  puedeEditarPedidos(): boolean { return this.esAdmin() || this.esGestorCompras(); }
  puedeEliminarPedidos(): boolean { return this.esAdmin(); }
  puedeCrearAdjudicaciones(): boolean { return this.esAdmin() || this.esGestorCompras(); }
  puedeEditarAdjudicaciones(): boolean { return this.esAdmin() || this.esGestorCompras(); }
  puedeVerReportes(): boolean { return this.esAdmin() || this.esAuditor() || this.esGestorCompras(); }

  puedeCrear(): boolean { return this.esAdmin() || this.esGestorCompras(); }
  puedeEditar(): boolean { return this.esAdmin() || this.esGestorCompras(); }
  puedeEliminar(): boolean { return this.esAdmin(); }

  getIdProveedor(): number | null {
    const usuario = this.getUsuario();
    if (usuario && usuario.id_Proveedor) {
      return usuario.id_Proveedor;
    }

    const token = this.getToken();
    if (!token) return null;

    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      const idProv = payload['IdProveedor'] || payload['idProveedor'];
      return idProv ? parseInt(idProv, 10) : null;
    } catch (error) {
      console.error('Error al decodificar el token:', error);
      return null;
    }
  }

  getNombreUsuario(): string {
    return localStorage.getItem('nombreUsuario') || 'Usuario';
  }

  // ✅ Método de respaldo
  getIdRubroProveedor(): number | null {
    return null; // Lo obtendremos desde el backend con ProveedorService
  }
}
